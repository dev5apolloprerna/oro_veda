<?php
ob_start();
unlink('/home/thewa4vq/wardrobe/storage/logs/laravel.log');
?>
