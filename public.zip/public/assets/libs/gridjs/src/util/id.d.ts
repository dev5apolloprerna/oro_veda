export declare type ID = string;
export declare function generateUUID(): ID;
